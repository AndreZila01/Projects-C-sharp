﻿namespace Jogo_da_Forca
{
	partial class Form2
	{
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Windows Form Designer generated code

		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.label1 = new System.Windows.Forms.Label();
			this.label2 = new System.Windows.Forms.Label();
			this.label3 = new System.Windows.Forms.Label();
			this.label4 = new System.Windows.Forms.Label();
			this.label5 = new System.Windows.Forms.Label();
			this.label6 = new System.Windows.Forms.Label();
			this.label7 = new System.Windows.Forms.Label();
			this.label8 = new System.Windows.Forms.Label();
			this.label9 = new System.Windows.Forms.Label();
			this.label10 = new System.Windows.Forms.Label();
			this.label11 = new System.Windows.Forms.Label();
			this.label12 = new System.Windows.Forms.Label();
			this.label13 = new System.Windows.Forms.Label();
			this.label14 = new System.Windows.Forms.Label();
			this.label15 = new System.Windows.Forms.Label();
			this.label16 = new System.Windows.Forms.Label();
			this.label17 = new System.Windows.Forms.Label();
			this.grpTeclado = new System.Windows.Forms.GroupBox();
			this.btnI = new System.Windows.Forms.Button();
			this.btnM = new System.Windows.Forms.Button();
			this.btnN = new System.Windows.Forms.Button();
			this.btnB = new System.Windows.Forms.Button();
			this.btnQ = new System.Windows.Forms.Button();
			this.btnW = new System.Windows.Forms.Button();
			this.btnV = new System.Windows.Forms.Button();
			this.btnE = new System.Windows.Forms.Button();
			this.btnC = new System.Windows.Forms.Button();
			this.btnR = new System.Windows.Forms.Button();
			this.btnT = new System.Windows.Forms.Button();
			this.btnX = new System.Windows.Forms.Button();
			this.btnY = new System.Windows.Forms.Button();
			this.btnZ = new System.Windows.Forms.Button();
			this.btnU = new System.Windows.Forms.Button();
			this.btnÇ = new System.Windows.Forms.Button();
			this.btnO = new System.Windows.Forms.Button();
			this.btnL = new System.Windows.Forms.Button();
			this.btnK = new System.Windows.Forms.Button();
			this.btnP = new System.Windows.Forms.Button();
			this.btnJ = new System.Windows.Forms.Button();
			this.btnA = new System.Windows.Forms.Button();
			this.btnS = new System.Windows.Forms.Button();
			this.btnH = new System.Windows.Forms.Button();
			this.btnG = new System.Windows.Forms.Button();
			this.btnD = new System.Windows.Forms.Button();
			this.btnF = new System.Windows.Forms.Button();
			this.button1 = new System.Windows.Forms.Button();
			this.textBox1 = new System.Windows.Forms.TextBox();
			this.label18 = new System.Windows.Forms.Label();
			this.grpTeclado.SuspendLayout();
			this.SuspendLayout();
			// 
			// label1
			// 
			this.label1.AutoSize = true;
			this.label1.Location = new System.Drawing.Point(31, 50);
			this.label1.Name = "label1";
			this.label1.Size = new System.Drawing.Size(13, 13);
			this.label1.TabIndex = 0;
			this.label1.Text = "_";
			// 
			// label2
			// 
			this.label2.AutoSize = true;
			this.label2.Location = new System.Drawing.Point(46, 50);
			this.label2.Name = "label2";
			this.label2.Size = new System.Drawing.Size(13, 13);
			this.label2.TabIndex = 1;
			this.label2.Text = "_";
			// 
			// label3
			// 
			this.label3.AutoSize = true;
			this.label3.Location = new System.Drawing.Point(61, 50);
			this.label3.Name = "label3";
			this.label3.Size = new System.Drawing.Size(13, 13);
			this.label3.TabIndex = 2;
			this.label3.Text = "_";
			// 
			// label4
			// 
			this.label4.AutoSize = true;
			this.label4.Location = new System.Drawing.Point(76, 50);
			this.label4.Name = "label4";
			this.label4.Size = new System.Drawing.Size(13, 13);
			this.label4.TabIndex = 3;
			this.label4.Text = "_";
			// 
			// label5
			// 
			this.label5.AutoSize = true;
			this.label5.Location = new System.Drawing.Point(91, 50);
			this.label5.Name = "label5";
			this.label5.Size = new System.Drawing.Size(13, 13);
			this.label5.TabIndex = 4;
			this.label5.Text = "_";
			// 
			// label6
			// 
			this.label6.AutoSize = true;
			this.label6.Location = new System.Drawing.Point(106, 50);
			this.label6.Name = "label6";
			this.label6.Size = new System.Drawing.Size(13, 13);
			this.label6.TabIndex = 5;
			this.label6.Text = "_";
			// 
			// label7
			// 
			this.label7.AutoSize = true;
			this.label7.Location = new System.Drawing.Point(121, 50);
			this.label7.Name = "label7";
			this.label7.Size = new System.Drawing.Size(13, 13);
			this.label7.TabIndex = 6;
			this.label7.Text = "_";
			// 
			// label8
			// 
			this.label8.AutoSize = true;
			this.label8.Location = new System.Drawing.Point(136, 50);
			this.label8.Name = "label8";
			this.label8.Size = new System.Drawing.Size(13, 13);
			this.label8.TabIndex = 7;
			this.label8.Text = "_";
			// 
			// label9
			// 
			this.label9.AutoSize = true;
			this.label9.Location = new System.Drawing.Point(151, 50);
			this.label9.Name = "label9";
			this.label9.Size = new System.Drawing.Size(13, 13);
			this.label9.TabIndex = 8;
			this.label9.Text = "_";
			// 
			// label10
			// 
			this.label10.AutoSize = true;
			this.label10.Location = new System.Drawing.Point(166, 50);
			this.label10.Name = "label10";
			this.label10.Size = new System.Drawing.Size(13, 13);
			this.label10.TabIndex = 9;
			this.label10.Text = "_";
			// 
			// label11
			// 
			this.label11.AutoSize = true;
			this.label11.Location = new System.Drawing.Point(181, 50);
			this.label11.Name = "label11";
			this.label11.Size = new System.Drawing.Size(13, 13);
			this.label11.TabIndex = 10;
			this.label11.Text = "_";
			// 
			// label12
			// 
			this.label12.AutoSize = true;
			this.label12.Location = new System.Drawing.Point(196, 50);
			this.label12.Name = "label12";
			this.label12.Size = new System.Drawing.Size(13, 13);
			this.label12.TabIndex = 11;
			this.label12.Text = "_";
			// 
			// label13
			// 
			this.label13.AutoSize = true;
			this.label13.Location = new System.Drawing.Point(211, 50);
			this.label13.Name = "label13";
			this.label13.Size = new System.Drawing.Size(13, 13);
			this.label13.TabIndex = 12;
			this.label13.Text = "_";
			// 
			// label14
			// 
			this.label14.AutoSize = true;
			this.label14.Location = new System.Drawing.Point(226, 50);
			this.label14.Name = "label14";
			this.label14.Size = new System.Drawing.Size(13, 13);
			this.label14.TabIndex = 13;
			this.label14.Text = "_";
			// 
			// label15
			// 
			this.label15.AutoSize = true;
			this.label15.Location = new System.Drawing.Point(241, 50);
			this.label15.Name = "label15";
			this.label15.Size = new System.Drawing.Size(13, 13);
			this.label15.TabIndex = 14;
			this.label15.Text = "_";
			// 
			// label16
			// 
			this.label16.AutoSize = true;
			this.label16.Location = new System.Drawing.Point(256, 50);
			this.label16.Name = "label16";
			this.label16.Size = new System.Drawing.Size(13, 13);
			this.label16.TabIndex = 15;
			this.label16.Text = "_";
			// 
			// label17
			// 
			this.label17.AutoSize = true;
			this.label17.Location = new System.Drawing.Point(271, 50);
			this.label17.Name = "label17";
			this.label17.Size = new System.Drawing.Size(13, 13);
			this.label17.TabIndex = 16;
			this.label17.Text = "_";
			// 
			// grpTeclado
			// 
			this.grpTeclado.Controls.Add(this.btnI);
			this.grpTeclado.Controls.Add(this.btnM);
			this.grpTeclado.Controls.Add(this.btnN);
			this.grpTeclado.Controls.Add(this.btnB);
			this.grpTeclado.Controls.Add(this.btnQ);
			this.grpTeclado.Controls.Add(this.btnW);
			this.grpTeclado.Controls.Add(this.btnV);
			this.grpTeclado.Controls.Add(this.btnE);
			this.grpTeclado.Controls.Add(this.btnC);
			this.grpTeclado.Controls.Add(this.btnR);
			this.grpTeclado.Controls.Add(this.btnT);
			this.grpTeclado.Controls.Add(this.btnX);
			this.grpTeclado.Controls.Add(this.btnY);
			this.grpTeclado.Controls.Add(this.btnZ);
			this.grpTeclado.Controls.Add(this.btnU);
			this.grpTeclado.Controls.Add(this.btnÇ);
			this.grpTeclado.Controls.Add(this.btnO);
			this.grpTeclado.Controls.Add(this.btnL);
			this.grpTeclado.Controls.Add(this.btnK);
			this.grpTeclado.Controls.Add(this.btnP);
			this.grpTeclado.Controls.Add(this.btnJ);
			this.grpTeclado.Controls.Add(this.btnA);
			this.grpTeclado.Controls.Add(this.btnS);
			this.grpTeclado.Controls.Add(this.btnH);
			this.grpTeclado.Controls.Add(this.btnG);
			this.grpTeclado.Controls.Add(this.btnD);
			this.grpTeclado.Controls.Add(this.btnF);
			this.grpTeclado.Location = new System.Drawing.Point(12, 75);
			this.grpTeclado.Name = "grpTeclado";
			this.grpTeclado.Size = new System.Drawing.Size(296, 111);
			this.grpTeclado.TabIndex = 17;
			this.grpTeclado.TabStop = false;
			this.grpTeclado.Text = "Teclado";
			// 
			// btnI
			// 
			this.btnI.Location = new System.Drawing.Point(198, 19);
			this.btnI.Name = "btnI";
			this.btnI.Size = new System.Drawing.Size(24, 23);
			this.btnI.TabIndex = 36;
			this.btnI.Tag = "I";
			this.btnI.Text = "I";
			this.btnI.UseVisualStyleBackColor = true;
			this.btnI.Click += new System.EventHandler(this.LetraClick);
			// 
			// btnM
			// 
			this.btnM.Location = new System.Drawing.Point(170, 77);
			this.btnM.Name = "btnM";
			this.btnM.Size = new System.Drawing.Size(24, 23);
			this.btnM.TabIndex = 31;
			this.btnM.Tag = "M";
			this.btnM.Text = "M";
			this.btnM.UseVisualStyleBackColor = true;
			this.btnM.Click += new System.EventHandler(this.LetraClick);
			// 
			// btnN
			// 
			this.btnN.Location = new System.Drawing.Point(142, 77);
			this.btnN.Name = "btnN";
			this.btnN.Size = new System.Drawing.Size(24, 23);
			this.btnN.TabIndex = 34;
			this.btnN.Tag = "N";
			this.btnN.Text = "N";
			this.btnN.UseVisualStyleBackColor = true;
			this.btnN.Click += new System.EventHandler(this.LetraClick);
			// 
			// btnB
			// 
			this.btnB.Location = new System.Drawing.Point(115, 77);
			this.btnB.Name = "btnB";
			this.btnB.Size = new System.Drawing.Size(24, 23);
			this.btnB.TabIndex = 35;
			this.btnB.Tag = "B";
			this.btnB.Text = "B";
			this.btnB.UseVisualStyleBackColor = true;
			this.btnB.Click += new System.EventHandler(this.LetraClick);
			// 
			// btnQ
			// 
			this.btnQ.Location = new System.Drawing.Point(5, 20);
			this.btnQ.Name = "btnQ";
			this.btnQ.Size = new System.Drawing.Size(24, 23);
			this.btnQ.TabIndex = 10;
			this.btnQ.Tag = "Q";
			this.btnQ.Text = "Q";
			this.btnQ.UseVisualStyleBackColor = true;
			this.btnQ.Click += new System.EventHandler(this.LetraClick);
			// 
			// btnW
			// 
			this.btnW.Location = new System.Drawing.Point(32, 19);
			this.btnW.Name = "btnW";
			this.btnW.Size = new System.Drawing.Size(24, 23);
			this.btnW.TabIndex = 11;
			this.btnW.Tag = "W";
			this.btnW.Text = "W";
			this.btnW.UseVisualStyleBackColor = true;
			this.btnW.Click += new System.EventHandler(this.LetraClick);
			// 
			// btnV
			// 
			this.btnV.Location = new System.Drawing.Point(86, 77);
			this.btnV.Name = "btnV";
			this.btnV.Size = new System.Drawing.Size(24, 23);
			this.btnV.TabIndex = 33;
			this.btnV.Tag = "V";
			this.btnV.Text = "V";
			this.btnV.UseVisualStyleBackColor = true;
			this.btnV.Click += new System.EventHandler(this.LetraClick);
			// 
			// btnE
			// 
			this.btnE.Location = new System.Drawing.Point(59, 19);
			this.btnE.Name = "btnE";
			this.btnE.Size = new System.Drawing.Size(24, 23);
			this.btnE.TabIndex = 12;
			this.btnE.Tag = "E";
			this.btnE.Text = "E";
			this.btnE.UseVisualStyleBackColor = true;
			this.btnE.Click += new System.EventHandler(this.LetraClick);
			// 
			// btnC
			// 
			this.btnC.Location = new System.Drawing.Point(59, 77);
			this.btnC.Name = "btnC";
			this.btnC.Size = new System.Drawing.Size(24, 23);
			this.btnC.TabIndex = 32;
			this.btnC.Tag = "C";
			this.btnC.Text = "C";
			this.btnC.UseVisualStyleBackColor = true;
			this.btnC.Click += new System.EventHandler(this.LetraClick);
			// 
			// btnR
			// 
			this.btnR.Location = new System.Drawing.Point(86, 19);
			this.btnR.Name = "btnR";
			this.btnR.Size = new System.Drawing.Size(24, 23);
			this.btnR.TabIndex = 13;
			this.btnR.Tag = "R";
			this.btnR.Text = "R";
			this.btnR.UseVisualStyleBackColor = true;
			this.btnR.Click += new System.EventHandler(this.LetraClick);
			// 
			// btnT
			// 
			this.btnT.Location = new System.Drawing.Point(115, 19);
			this.btnT.Name = "btnT";
			this.btnT.Size = new System.Drawing.Size(24, 23);
			this.btnT.TabIndex = 14;
			this.btnT.Tag = "T";
			this.btnT.Text = "T";
			this.btnT.UseVisualStyleBackColor = true;
			this.btnT.Click += new System.EventHandler(this.LetraClick);
			// 
			// btnX
			// 
			this.btnX.Location = new System.Drawing.Point(32, 77);
			this.btnX.Name = "btnX";
			this.btnX.Size = new System.Drawing.Size(24, 23);
			this.btnX.TabIndex = 30;
			this.btnX.Tag = "X";
			this.btnX.Text = "X";
			this.btnX.UseVisualStyleBackColor = true;
			this.btnX.Click += new System.EventHandler(this.LetraClick);
			// 
			// btnY
			// 
			this.btnY.Location = new System.Drawing.Point(142, 19);
			this.btnY.Name = "btnY";
			this.btnY.Size = new System.Drawing.Size(24, 23);
			this.btnY.TabIndex = 15;
			this.btnY.Tag = "Y";
			this.btnY.Text = "Y";
			this.btnY.UseVisualStyleBackColor = true;
			this.btnY.Click += new System.EventHandler(this.LetraClick);
			// 
			// btnZ
			// 
			this.btnZ.Location = new System.Drawing.Point(5, 77);
			this.btnZ.Name = "btnZ";
			this.btnZ.Size = new System.Drawing.Size(24, 23);
			this.btnZ.TabIndex = 29;
			this.btnZ.Tag = "Z";
			this.btnZ.Text = "Z";
			this.btnZ.UseVisualStyleBackColor = true;
			this.btnZ.Click += new System.EventHandler(this.LetraClick);
			// 
			// btnU
			// 
			this.btnU.Location = new System.Drawing.Point(170, 19);
			this.btnU.Name = "btnU";
			this.btnU.Size = new System.Drawing.Size(24, 23);
			this.btnU.TabIndex = 16;
			this.btnU.Tag = "U";
			this.btnU.Text = "U";
			this.btnU.UseVisualStyleBackColor = true;
			this.btnU.Click += new System.EventHandler(this.LetraClick);
			// 
			// btnÇ
			// 
			this.btnÇ.Location = new System.Drawing.Point(255, 48);
			this.btnÇ.Name = "btnÇ";
			this.btnÇ.Size = new System.Drawing.Size(24, 23);
			this.btnÇ.TabIndex = 28;
			this.btnÇ.Tag = "Ç";
			this.btnÇ.Text = "Ç";
			this.btnÇ.UseVisualStyleBackColor = true;
			this.btnÇ.Click += new System.EventHandler(this.LetraClick);
			// 
			// btnO
			// 
			this.btnO.Location = new System.Drawing.Point(225, 19);
			this.btnO.Name = "btnO";
			this.btnO.Size = new System.Drawing.Size(24, 23);
			this.btnO.TabIndex = 17;
			this.btnO.Tag = "O";
			this.btnO.Text = "O";
			this.btnO.UseVisualStyleBackColor = true;
			this.btnO.Click += new System.EventHandler(this.LetraClick);
			// 
			// btnL
			// 
			this.btnL.Location = new System.Drawing.Point(225, 48);
			this.btnL.Name = "btnL";
			this.btnL.Size = new System.Drawing.Size(24, 23);
			this.btnL.TabIndex = 25;
			this.btnL.Tag = "L";
			this.btnL.Text = "L";
			this.btnL.UseVisualStyleBackColor = true;
			this.btnL.Click += new System.EventHandler(this.LetraClick);
			// 
			// btnK
			// 
			this.btnK.Location = new System.Drawing.Point(198, 48);
			this.btnK.Name = "btnK";
			this.btnK.Size = new System.Drawing.Size(24, 23);
			this.btnK.TabIndex = 27;
			this.btnK.Tag = "K";
			this.btnK.Text = "K";
			this.btnK.UseVisualStyleBackColor = true;
			this.btnK.Click += new System.EventHandler(this.LetraClick);
			// 
			// btnP
			// 
			this.btnP.Location = new System.Drawing.Point(255, 19);
			this.btnP.Name = "btnP";
			this.btnP.Size = new System.Drawing.Size(24, 23);
			this.btnP.TabIndex = 18;
			this.btnP.Tag = "P";
			this.btnP.Text = "P";
			this.btnP.UseVisualStyleBackColor = true;
			this.btnP.Click += new System.EventHandler(this.LetraClick);
			// 
			// btnJ
			// 
			this.btnJ.Location = new System.Drawing.Point(170, 48);
			this.btnJ.Name = "btnJ";
			this.btnJ.Size = new System.Drawing.Size(24, 23);
			this.btnJ.TabIndex = 26;
			this.btnJ.Tag = "J";
			this.btnJ.Text = "J";
			this.btnJ.UseVisualStyleBackColor = true;
			this.btnJ.Click += new System.EventHandler(this.LetraClick);
			// 
			// btnA
			// 
			this.btnA.Location = new System.Drawing.Point(5, 48);
			this.btnA.Name = "btnA";
			this.btnA.Size = new System.Drawing.Size(24, 23);
			this.btnA.TabIndex = 19;
			this.btnA.Tag = "A";
			this.btnA.Text = "A";
			this.btnA.UseVisualStyleBackColor = true;
			this.btnA.Click += new System.EventHandler(this.LetraClick);
			// 
			// btnS
			// 
			this.btnS.Location = new System.Drawing.Point(32, 48);
			this.btnS.Name = "btnS";
			this.btnS.Size = new System.Drawing.Size(24, 23);
			this.btnS.TabIndex = 20;
			this.btnS.Tag = "S";
			this.btnS.Text = "S";
			this.btnS.UseVisualStyleBackColor = true;
			this.btnS.Click += new System.EventHandler(this.LetraClick);
			// 
			// btnH
			// 
			this.btnH.Location = new System.Drawing.Point(142, 48);
			this.btnH.Name = "btnH";
			this.btnH.Size = new System.Drawing.Size(24, 23);
			this.btnH.TabIndex = 23;
			this.btnH.Tag = "H";
			this.btnH.Text = "H";
			this.btnH.UseVisualStyleBackColor = true;
			this.btnH.Click += new System.EventHandler(this.LetraClick);
			// 
			// btnG
			// 
			this.btnG.Location = new System.Drawing.Point(116, 48);
			this.btnG.Name = "btnG";
			this.btnG.Size = new System.Drawing.Size(24, 23);
			this.btnG.TabIndex = 24;
			this.btnG.Tag = "G";
			this.btnG.Text = "G";
			this.btnG.UseVisualStyleBackColor = true;
			this.btnG.Click += new System.EventHandler(this.LetraClick);
			// 
			// btnD
			// 
			this.btnD.Location = new System.Drawing.Point(59, 48);
			this.btnD.Name = "btnD";
			this.btnD.Size = new System.Drawing.Size(24, 23);
			this.btnD.TabIndex = 21;
			this.btnD.Tag = "D";
			this.btnD.Text = "D";
			this.btnD.UseVisualStyleBackColor = true;
			this.btnD.Click += new System.EventHandler(this.LetraClick);
			// 
			// btnF
			// 
			this.btnF.Location = new System.Drawing.Point(86, 48);
			this.btnF.Name = "btnF";
			this.btnF.Size = new System.Drawing.Size(24, 23);
			this.btnF.TabIndex = 22;
			this.btnF.Tag = "F";
			this.btnF.Text = "F";
			this.btnF.UseVisualStyleBackColor = true;
			this.btnF.Click += new System.EventHandler(this.LetraClick);
			// 
			// button1
			// 
			this.button1.Location = new System.Drawing.Point(332, 103);
			this.button1.Name = "button1";
			this.button1.Size = new System.Drawing.Size(75, 23);
			this.button1.TabIndex = 18;
			this.button1.Text = "Ready";
			this.button1.UseVisualStyleBackColor = true;
			this.button1.Click += new System.EventHandler(this.Button1_Click);
			// 
			// textBox1
			// 
			this.textBox1.Location = new System.Drawing.Point(307, 40);
			this.textBox1.Name = "textBox1";
			this.textBox1.Size = new System.Drawing.Size(100, 20);
			this.textBox1.TabIndex = 19;
			// 
			// label18
			// 
			this.label18.AutoSize = true;
			this.label18.Location = new System.Drawing.Point(304, 24);
			this.label18.Name = "label18";
			this.label18.Size = new System.Drawing.Size(32, 13);
			this.label18.TabIndex = 20;
			this.label18.Text = "Dica:";
			// 
			// Form2
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.ClientSize = new System.Drawing.Size(420, 190);
			this.Controls.Add(this.label18);
			this.Controls.Add(this.textBox1);
			this.Controls.Add(this.button1);
			this.Controls.Add(this.grpTeclado);
			this.Controls.Add(this.label17);
			this.Controls.Add(this.label16);
			this.Controls.Add(this.label15);
			this.Controls.Add(this.label14);
			this.Controls.Add(this.label13);
			this.Controls.Add(this.label12);
			this.Controls.Add(this.label11);
			this.Controls.Add(this.label10);
			this.Controls.Add(this.label9);
			this.Controls.Add(this.label8);
			this.Controls.Add(this.label7);
			this.Controls.Add(this.label6);
			this.Controls.Add(this.label5);
			this.Controls.Add(this.label4);
			this.Controls.Add(this.label3);
			this.Controls.Add(this.label2);
			this.Controls.Add(this.label1);
			this.Cursor = System.Windows.Forms.Cursors.Arrow;
			this.Name = "Form2";
			this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
			this.Text = "Form2";
			this.Load += new System.EventHandler(this.Form2_Load);
			this.grpTeclado.ResumeLayout(false);
			this.ResumeLayout(false);
			this.PerformLayout();

		}

		#endregion

		private System.Windows.Forms.Label label1;
		private System.Windows.Forms.Label label2;
		private System.Windows.Forms.Label label3;
		private System.Windows.Forms.Label label4;
		private System.Windows.Forms.Label label5;
		private System.Windows.Forms.Label label6;
		private System.Windows.Forms.Label label7;
		private System.Windows.Forms.Label label8;
		private System.Windows.Forms.Label label9;
		private System.Windows.Forms.Label label10;
		private System.Windows.Forms.Label label11;
		private System.Windows.Forms.Label label12;
		private System.Windows.Forms.Label label13;
		private System.Windows.Forms.Label label14;
		private System.Windows.Forms.Label label15;
		private System.Windows.Forms.Label label16;
		private System.Windows.Forms.Label label17;
		private System.Windows.Forms.GroupBox grpTeclado;
		private System.Windows.Forms.Button btnI;
		private System.Windows.Forms.Button btnM;
		private System.Windows.Forms.Button btnN;
		private System.Windows.Forms.Button btnB;
		private System.Windows.Forms.Button btnQ;
		private System.Windows.Forms.Button btnW;
		private System.Windows.Forms.Button btnV;
		private System.Windows.Forms.Button btnE;
		private System.Windows.Forms.Button btnC;
		private System.Windows.Forms.Button btnR;
		private System.Windows.Forms.Button btnT;
		private System.Windows.Forms.Button btnX;
		private System.Windows.Forms.Button btnY;
		private System.Windows.Forms.Button btnZ;
		private System.Windows.Forms.Button btnU;
		private System.Windows.Forms.Button btnÇ;
		private System.Windows.Forms.Button btnO;
		private System.Windows.Forms.Button btnL;
		private System.Windows.Forms.Button btnK;
		private System.Windows.Forms.Button btnP;
		private System.Windows.Forms.Button btnJ;
		private System.Windows.Forms.Button btnA;
		private System.Windows.Forms.Button btnS;
		private System.Windows.Forms.Button btnH;
		private System.Windows.Forms.Button btnG;
		private System.Windows.Forms.Button btnD;
		private System.Windows.Forms.Button btnF;
		private System.Windows.Forms.Button button1;
		private System.Windows.Forms.TextBox textBox1;
		private System.Windows.Forms.Label label18;
	}
}